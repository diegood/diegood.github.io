// -----------------------------------------------
//            VARIABLES GLOBALES
// -----------------------------------------------
let listaProductos = []


// -----------------------------------------------
//                 FUNCIONES
// -----------------------------------------------
function guardarListaProductosLocal(lista) {
    let prod = JSON.stringify(lista)
    localStorage.setItem('LISTA', prod)
}

function leerListaProductosLocal(lista) {
    if(localStorage.getItem('LISTA')) {
        lista = JSON.parse(localStorage.getItem('LISTA'))
    }

    return lista
}


function borrarProd(id) {
    console.log(id)

    api.deleteProdWeb(id, prod => {
        //listaProductos.splice(index, 1)
        renderLista()
        console.log('delete', prod)
    })
}



function cambiarCantidad(id, e) {
    let cantidad = Number(e.value)
    let index = listaProductos.findIndex(prod => prod.id == id)
    console.log('cambiarCantidad',id, index,cantidad)

    listaProductos[index].cantidad = cantidad
    let prod = listaProductos[index]

    /* guardamos los productos en el localStorage */
    guardarListaProductosLocal(listaProductos)

    api.updateProdWeb(id, prod, prod => {
        console.log('update cantidad', prod)
    })
}

function cambiarPrecio(id, e) {
    let precio = Number(e.value)
    let index = listaProductos.findIndex(prod => prod.id == id)

    console.log('cambiarPrecio',id,index,precio)
    listaProductos[index]['precio'] = precio
    let prod = listaProductos[index]

    /* guardamos los productos en el localStorage */
    guardarListaProductosLocal(listaProductos)

    api.updateProdWeb(id, prod, prod => {
        console.log('update precio', prod)
    })
}

function configurarListeners() {
    $('#btn-entrada-producto').click( () => {

        console.log('btn-entrada-producto')

        let input = $('#ingreso-producto')
        let producto = input.val()

        console.log(producto)
        if(producto != '') {

            //listaProductos.push({
            let prod = {
                nombre: producto,
                cantidad: 1,
                precio: 0
            }

            api.postProdWeb(prod, prod => {
                console.log('post', prod)
                renderLista()
                input.val('')
            })
        }
    })

    $('#btn-borrar-productos').click( () => {
        console.log('borrar productos')

        //listaProductos = []
        api.deleteAllProdWeb( info => {
            console.log(info)
            renderLista()
        })
    })
}


function renderLista() {

    $.ajax({url: 'plantilla-lista.hbs', method: 'get'})
    .then( source => {
        //console.log(source)
        const template = Handlebars.compile(source)

        /* Pido los datos a MockApi.io */
        api.getProdWeb(prods => {
            listaProductos = prods

            /* guardamos los productos en el localStorage */
            guardarListaProductosLocal(listaProductos)

            let data = {listaProductos} // igual a {listaProductos : listaProductos}
            $('#lista').html(template(data))
        
            let ul = $('#contenedor-lista')
            componentHandler.upgradeElements(ul)
        })

    })
    .catch(error => console.log('Error en renderLista:', error))
}

function registrarServiceWorker() {
    if(window.caches) {
        if('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                
                this.navigator.serviceWorker.register('./sw.js').then( reg => {
                    console.log('El service worker se registró correctamente', reg)
                    reg.onupdatefound = () => {
                        const installingWorker = reg.installing
                        installingWorker.onstatechange = () => {
                            if(installingWorker.state === 'activated' &&
                                this.navigator.serviceWorker.controller
                            ) {
                                this.console.log('REINICIANDO')
                                this.setTimeout(() => {
                                    this.location.reload()
                                },1000)
                            }
                        }
                    }
                })
                .catch(function(err) {
                    console.warn('Error al registrar el service worker', err)
                })
            })
        }
    }
    else {
        console.log('Caches no soportado')
    }
}

function start() {
    registrarServiceWorker()
    configurarListeners()
    renderLista()
    //pruebaCaches()
}

// -----------------------------------------------
//                 EJECUCIÓN
// -----------------------------------------------
$(document).ready(start)


// -----------------------------------------------
//       PRUEBA DE CACHE STORAGE (caches)
//      https://caniuse.com/#search=caches
// -----------------------------------------------
function pruebaCaches() {
    if(window.caches) {
        console.log('El browser soporte Caches!')

        caches.open('prueba-1')
        caches.open('prueba-2')
        caches.open('prueba-3')

        caches.has('prueba-3').then(console.log) //igual a .then(rta => console.log(rta))

        caches.delete('prueba-1').then(console.log)

        caches.keys().then(console.log)

        caches.open('cache-v1.1').then(cache => {
            //cache.add('/index.html')
            cache.addAll([
                '/index.html',
                '/css/estilos.css',
                '/images/super.jpg'
            ]).then(() => {
                console.log('recursos agregados')

                //cache.delete('/css/estilos.css').then(console.log)

                //cache.match('/index.html').then(res => {
                cache.match('/css/estilos.css').then(res => {
                        if(res) {
                        console.log('Recurso encontrado')
                        res.text().then(console.log)
                    }
                    else {
                        console.log('Recurso inexistente')
                    }
                })

                cache.put('/index.html', new Response('Hola mundo!'))

                cache.keys().then(recursos => console.log('Recursos de cache: ', recursos))
                cache.keys().then(recursos => {
                    recursos.forEach(recurso => {
                        console.log(recurso.url)
                    })
                })

                caches.keys().then(nombres => {
                    console.log('Nombre de Caches: ', nombres)
                })
            })
        })
    }
    else {
        console.log('Caches no soportado')
    }
}



