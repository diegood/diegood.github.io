const api = (function() {

    /* ------------------------------------ */
    /*               API REST               */
    /* ------------------------------------ */

    function getURL() {
        return 'https://5c8ef17a3e557700145e85c7.mockapi.io/lista/'
    }

    /* ----------- */
    /*     GET     */
    /* ----------- */
    function getProdWeb(cb) {
        let url = getURL()+'?'+Date.now()
        //console.log(url)

        $.ajax({url, method: 'get'})
        .then(cb)
        .catch(error => {
            console.log(error)
            listaProductos = leerListaProductosLocal(listaProductos)
            cb(listaProductos)
        })
    }

    /* -------------- */
    /*     DELETE     */
    /* -------------- */
    function deleteProdWeb(id,cb) {
        let url = getURL()+id
        //console.log(url)

        $.ajax({url, method: 'delete'})
        .then(cb)
        .catch(error => {
            console.log(error)
            cb('error')
        })
    }

    /* -------------- */
    /*     UPDATE     */
    /* -------------- */
    function updateProdWeb(id, prod, cb) {
        let url = getURL()+id
        //console.log(url)

        $.ajax({url: url, data: prod, method: 'put'})
        .then(cb)
        .catch(error => {
            console.log(error)
            cb('error')
        })
    }

    /* -------------- */
    /*      POST      */
    /* -------------- */
    function postProdWeb(prod, cb) {
        let url = getURL()
        //console.log(url)

        $.ajax({url: url, data: prod, method: 'post'})
        .then(cb)
        .catch(error => {
            console.log(error)
            cb('error')
        })
    }

    async function deleteAllProdWeb(cb) {
        let porcentaje = 0
        let progress = document.querySelector('progress')
        let btnBorrarProductos= document.querySelector('#btn-borrar-productos')

        progress.value = 0
        progress.style.display = 'block'
        btnBorrarProductos.setAttribute('disabled', true)

        for(let i=0; i<listaProductos.length; i++) {

            porcentaje = parseInt((i*100) / listaProductos.length)
            console.log(porcentaje + '%')
            progress.value = porcentaje


            try {
                let url = getURL() + listaProductos[i].id
                let p = await $.ajax({url, method: 'delete'})
                //console.log('producto borrado', p)
            }
            catch(error) {
                let err = {
                    info: 'error',
                    error
                }
                cb(err)               
            }
        }
        porcentaje = 100
        progress.value = porcentaje

        setTimeout(() => {
            progress.style.display = 'none'
            btnBorrarProductos.removeAttribute('disabled')
        },2000)



        console.log(porcentaje + '%')
        cb('ok')
    }
    //-----------------------------------------------------------

    return {
        getProdWeb,
        postProdWeb,
        updateProdWeb,
        deleteProdWeb,
        deleteAllProdWeb
    }

})()