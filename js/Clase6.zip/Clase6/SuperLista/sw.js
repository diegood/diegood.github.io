const CACHE_STATIC_NAME = 'static-v9'
const CACHE_INMUTABLE_NAME = 'inmutable-v9'
const CACHE_DYNAMIC_NAME = 'dynamic-v9'

self.addEventListener('install', e => {
    console.log('sw install!!')

    self.skipWaiting()

    //------------------------------------------------------------
    // Guardar recursos de la APP SHELL en el cache
    //------------------------------------------------------------
    //const cacheStatic = caches.open('cache-1').then(cache => {
    const cacheStatic = caches.open(CACHE_STATIC_NAME).then(cache => {
        return cache.addAll([
            '/index.html',
            '/css/estilos.css',
            '/js/main.js',
            '/js/api.js',
            '/plantilla-lista.hbs',
            '/images/super.jpg'
        ])
    })

    const cacheInmutable = caches.open(CACHE_INMUTABLE_NAME).then(cache => {
        return cache.addAll([
            '/js/handlebars-v4.7.6.js',
            'https://code.getmdl.io/1.3.0/material.indigo-pink.min.css',
            'https://code.getmdl.io/1.3.0/material.min.js',
            'https://code.jquery.com/jquery-3.5.1.min.js'
        ])
    })
    
    e.waitUntil(Promise.all([cacheStatic, cacheInmutable]))
})

self.addEventListener('activate', e => {
    console.log('sw activate!!')

    const cacheWhiteList = [
        CACHE_STATIC_NAME,
        CACHE_INMUTABLE_NAME,
        CACHE_DYNAMIC_NAME
    ]

    e.waitUntil(
        caches.keys().then(keys => {
            console.log(keys)
            return Promise.all(
                keys.map(cache => {
                    console.log(cache)
                    if(!cacheWhiteList.includes(cache)) {
                        return caches.delete(cache)
                    }
                })
            )
        })
    )
})

self.addEventListener('fetch', e => {
    //console.log('sw fetch!')

    //console.log(e.request.url)
    //e.respondWith(fetch(e.request))
    if(e.request.method == 'GET' && !e.request.url.includes('mockapi.io') ) {
        const respuesta = caches.match(e.request).then( res => {
            if(res) {
                console.log('EXISTE EN CACHE', e.request.url)
                return res
            }
            console.log('NO EXISTE EN CACHE', e.request.url)
            return fetch(e.request).then(nuevaRespuesta => {
                caches.open(CACHE_DYNAMIC_NAME).then(cache => {
                    cache.put(e.request, nuevaRespuesta)
                })
                return nuevaRespuesta.clone()
            })
        })
        e.respondWith(respuesta)
    }
    else {
        console.log('BYPASS', e.request.method, e.request.url)
    }

})

self.addEventListener('push', e => {
    console.log('push!', e)
})
