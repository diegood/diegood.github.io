// -----------------------------------------------
//            VARIABLES GLOBALES
// -----------------------------------------------
let listaProductos = []


// -----------------------------------------------
//                 FUNCIONES
// -----------------------------------------------
function guardarListaProductosLocal(lista) {
    let prod = JSON.stringify(lista)
    localStorage.setItem('LISTA', prod)
}

function leerListaProductosLocal(lista) {
    if(localStorage.getItem('LISTA')) {
        lista = JSON.parse(localStorage.getItem('LISTA'))
    }

    return lista
}

function borrarProd(id) {
    console.log(id)

    api.deleteProdWeb(id, prod => {
        //listaProductos.splice(index, 1)
        renderLista()
        console.log('delete', prod)
    })
}

function cambiarCantidad(id, e) {
    let cantidad = Number(e.value)
    let index = listaProductos.findIndex(prod => prod.id == id)
    console.log('cambiarCantidad',id, index,cantidad)

    listaProductos[index].cantidad = cantidad
    let prod = listaProductos[index]

    /* guardamos los productos en el localStorage */
    guardarListaProductosLocal(listaProductos)

    api.updateProdWeb(id, prod, prod => {
        console.log('update cantidad', prod)
    })
}

function cambiarPrecio(id, e) {
    let precio = Number(e.value)
    let index = listaProductos.findIndex(prod => prod.id == id)

    console.log('cambiarPrecio',id,index,precio)
    listaProductos[index]['precio'] = precio
    let prod = listaProductos[index]

    /* guardamos los productos en el localStorage */
    guardarListaProductosLocal(listaProductos)

    api.updateProdWeb(id, prod, prod => {
        console.log('update precio', prod)
    })
}

function configurarListeners() {
    $('#btn-entrada-producto').click( () => {

        console.log('btn-entrada-producto')

        let input = $('#ingreso-producto')
        let producto = input.val()

        console.log(producto)
        if(producto != '') {

            //listaProductos.push({
            let prod = {
                nombre: producto,
                cantidad: 1,
                precio: 0
            }

            api.postProdWeb(prod, prod => {
                console.log('post', prod)
                renderLista()
                input.val('')
            })
        }
    })

    $('#btn-borrar-productos').click( () => {
        console.log('borrar productos')

        //listaProductos = []
        api.deleteAllProdWeb( info => {
            console.log(info)
            renderLista()
        })
    })
}


function renderLista() {

    $.ajax({url: 'plantilla-lista.hbs', method: 'get'})
    .then( source => {
        //console.log(source)
        const template = Handlebars.compile(source)

        /* Pido los datos a MockApi.io */
        api.getProdWeb(prods => {
            listaProductos = prods

            /* guardamos los productos en el localStorage */
            guardarListaProductosLocal(listaProductos)

            let data = {listaProductos} // igual a {listaProductos : listaProductos}
            $('#lista').html(template(data))
        
            let ul = $('#contenedor-lista')
            componentHandler.upgradeElements(ul)
        })

    })
    .catch(error => console.log('Error en renderLista:', error))
}

function registrarServiceWorker() {
    if(window.caches) {
        if('serviceWorker' in navigator && 'PushManager' in window) {
            window.addEventListener('load', function() {
                
                this.navigator.serviceWorker.register('./sw.js').then( reg => {
                    //console.log('El service worker se registró correctamente', reg)
                    
                    notificaciones.initialiseUI(reg)

                    Notification.requestPermission(function (res) {
                        if (res === 'granted') {
                            navigator.serviceWorker.ready.then(function (reg) {
                            })
                        }
                    })
                    
                    /* RESET */
                    reg.onupdatefound = () => {
                        const installingWorker = reg.installing
                        installingWorker.onstatechange = () => {
                            if(installingWorker.state === 'activated' &&
                                this.navigator.serviceWorker.controller
                            ) {
                                this.console.log('REINICIANDO')
                                this.setTimeout(() => {
                                    this.location.reload()
                                },1000)
                            }
                        }
                    }
                })
                .catch(function(err) {
                    console.warn('Error al registrar el service worker', err)
                })
            })
        }
    }
    else {
        console.log('Caches no soportado')
    }
}

function start() {
    registrarServiceWorker()
    configurarListeners()
    renderLista()
}

// -----------------------------------------------
//                 EJECUCIÓN
// -----------------------------------------------
$(document).ready(start)
